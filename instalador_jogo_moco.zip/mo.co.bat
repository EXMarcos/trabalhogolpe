@echo off
title Virus Educacional - Criando atalhos

:: Loop para criar atalhos na Área de Trabalho
for /L %%i in (1,1,30) do (
    echo Criando atalho %%i
    echo [InternetShortcut] > "%userprofile%\Desktop\Atalho_Educacional_%%i.url"
    echo URL=https://www.google.com >> "%userprofile%\Desktop\Atalho_Educacional_%%i.url"
)

:: Mensagem para o usuário
echo.
echo Simulando comportamento de vírus educacional...
timeout /t 5 /nobreak

:: Reiniciar o PC após contagem regressiva
shutdown /r /t 10 /c "Este é um exercício educacional. O PC vai reiniciar em 10 segundos."

exit
